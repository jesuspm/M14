import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-series',
  templateUrl: './series.page.html',
  styleUrls: ['./series.page.scss'],
})
export class SeriesPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  remove(i){
    console.log(i);
    this.series.splice(i, 1);
  }

  series =  [{"name": "Stranger Things",
                "birth_year": "2011",
                "img": "strangerthings.png",
                "fav": 0
              },{"name": "La casa de papel",
                 "birth_year": "2012",
                 "img": "lacasadepapel.jpg",
                 "fav": 0
              },{"name": "Dark",
                "birth_year": "2015",
                "img": "dark.jpg",
                "fav": 0
              },{"name": "Vikingos",
                "birth_year": "2010",
                "img": "vikingos.jpg",
                "fav": 0
              },{"name": "El juego del calamar",
                "birth_year": "2021",
                "img": "eljuegodelcalamar.jpg",
                "fav": 0
              },{"name": "Los Simpsons",
                "birth_year": "1998",
                "img": "lossimpson.jpg",
                "fav": 0
              },{"name": "Peaky Blinders",
                "birth_year": "2020",
                "img": "peakyblinders.jpg",
                "fav": 0
            }];

}
