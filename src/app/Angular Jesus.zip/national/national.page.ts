import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-national',
  templateUrl: './national.page.html',
  styleUrls: ['./national.page.scss'],
})
export class NationalPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
